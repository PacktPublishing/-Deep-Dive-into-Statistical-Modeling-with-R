# alpha = 0.05 , alpha/2 =0.025

qnorm(0.975)

#2.6>1.96 p-value<0.025

1-pnorm(2.6)

