string_vec <- c("1","2","3","4","5")

string_vec*2

numeric_vec <- as.numeric(string_vec)

numeric_vec*2

date_example <- "2010-12-22"

date_example

as.Date(date_example,'%Y-%m-%d')

date_str <- c("1feb2006","1mar2016","1apr2017")

as.Date(date_str,"%d%b%Y")

