#Example 1 
#Assume that scores of Math exam(x) has normal distribution 
#with 50 mean and 10 standart deviation. 
#Calculate
#P(x<76) 
#P(x>45)
#P(85<x<90)
#=========================#
#P(x<76) 
z <- (76-50)/10
pnorm(z)

#=========================#
#P(x>45)
z <- (45-50)/10
1-pnorm(z)

#=========================#
#P(85<x<90)
z1 <- (90-50)/10
z2 <- (85-50)/10
pnorm(z1)-pnorm(z2)


#Example 2
#Assume that mean response time of a call center specialist is 2 minutes.
#Find the probability of a response time of a call center specialist 
#less than 3 minutes.

pexp(3, rate=1/2)

#Example 3
#Assume that x has two parametered weibull distribution 
#with the parameters shape =3 and scale = 2. 
#Calculate 
#P(x<2)
#P(x<1.5)
#P(1<x<2.2)

#=========================#
#P(x<2)

pweibull(2, shape = 3, scale = 2)

#=========================#
#P(x<1.5)

pweibull(1.5, shape = 3, scale = 2)

#=========================#
#P(1<x<2.2)

p1<-pweibull(2.2, shape = 3, scale = 2)
p2<-pweibull(1, shape = 3, scale = 2)

p1-p2
         