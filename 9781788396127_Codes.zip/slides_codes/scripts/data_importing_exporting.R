getwd()

list.files()

dd <- read.csv("R Workshop/Data/tufe.csv",header = T,sep=",")

head(dd)

write.csv(dd,"example.csv")

list.files()

pr <- read.table("R Workshop/Data/price",header = T,sep = ";")

head(pr)

write.csv(pr$pp,"example_price.csv")
