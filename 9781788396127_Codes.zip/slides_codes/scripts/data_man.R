basic_string <- c("name,surname,phone")

basic_string

help("strsplit")

splitted_vector <- strsplit(basic_string,",")

splitted_vector

length(splitted_vector[[1]])

length(basic_string)

splitted_vector[[1]][1]

splitted_vector[[1]][2]

help("str_replace_all")

install.packages(stringr)

library(stringr)

str_replace_all(basic_string,",",".")

