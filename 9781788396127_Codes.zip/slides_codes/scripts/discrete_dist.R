#Example 1 
#Assume that a basket player scores with 0.6 probability. 
#What is the probability of scoring 3 out of 10 shots ? 

dbinom(3,10,0.6)

#Example 2
#Assume that a basket player scores with 0.6 probability.
#What is the probability of scoring at most 3 out of 10 shots ? 

pbinom(3,10,0.6)

#Example 3
#If there are 30 cars crossing Istanbul bosphorus  per minute on average, 
#find the probability of having 35 or more cars crossing the bosphorus 
#in a particular minute.

(1-ppois(35, lambda=30))

#Example 4
#What is the probability you get the 6th cross before the 5th head,
#flipping a coin?

dnbinom(6,5,0.5)

