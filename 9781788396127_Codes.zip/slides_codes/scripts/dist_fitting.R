##distribution fitting

library(fitdistrplus)

x<-rweibull(50000,10,3)

fg <- fitdist(x, "gamma")
fn <- fitdist(x, "norm")
fw <- fitdist(x, "weibull")

plot.legend <- c("gamma", "normal","weibull")

denscomp(list(fg,fn,fw), legendtext = plot.legend)
qqcomp(list(fg, fn, fw), legendtext = plot.legend)

gofstat(list(fg, fn, fw), fitnames = c("gamma", "normal", "weibull"))
