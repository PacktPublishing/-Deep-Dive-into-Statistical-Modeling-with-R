x<-rnorm(500)

mean(x)

##

sd(x)

##

var(x)

##

median(x)
