airquality
colMeans(airquality)
colMeans(airquality,na.rm = TRUE)
summary(airquality)


hist(airquality$Wind)
plot(airquality$Wind,airquality$Temp)


courses<- c("math", "stats", "physics")
avg_scores <- c(60, 78, 65)
data <- data.frame(courses, avg_scores)
p <- plot_ly(data, x = ~courses, y = ~avg_scores, type = 'bar', name = 'avg_scores')
