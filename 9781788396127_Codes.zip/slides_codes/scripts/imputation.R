
data(bush10)
impdata<-impSeqRob(bush10,0.8)
