airquality

#cntrl+l to clear screen

typeof(airquality)

airquality_matrix <- as.matrix(airquality)

head(airquality_matrix)

col <- c("col1", "col2", "col3", "col4","col5", "col6")

colnames(airquality_matrix) <- col

airquality_df <- as.data.frame(airquality_matrix)

head(airquality_df)

head(airquality_matrix[,1])

head(airquality_matrix[,2])

head(airquality_df$col3)

concat_variable <- data.frame(airquality_df$col2, airquality_df$col3)

head(concat_variable)





