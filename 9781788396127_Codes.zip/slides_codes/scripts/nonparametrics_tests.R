##wilcoxon-rank-test/Mann Whitney U-Test
a = runif(15)
b = runif(15)

wilcox.test(b,a, correct=FALSE)

##kruskal_wallis test
kruskal.test(Ozone ~ Month, data = airquality) 
