#ttest
#H0: mean(x)=mean(y)
#H1: mean(x)<>mean(y)
x <- rnorm(10)
y <- rnorm(10)
t.test(x,y)

#ANOVA

head(cnufus)
summary(aov(toplam_nufus~c.cluster,data=cnufus))


#normality_test

shapiro.test(rnorm(100, mean = 5, sd = 3))
shapiro.test(runif(100, min = 2, max = 4))

