install.packages("RPostgreSQL")
library("RPostgreSQL")

#Postgre driver is loaded.
drv <- dbDriver("PostgreSQL")

#Getting connection
con <- dbConnect(drv, dbname = "development",    host = "development.clgjf7569y1t.us-west-2.rds.amazonaws.com",port=5432,
                 user = "olgun", password = "olgun88ay")

#select from a table
all_data<-dbGetQuery(con,"select * from prices")

distinct_cat<-dbGetQuery(con,"select distinct revmcc from prices")

distinct_scat<-dbGetQuery(con,"select distinct revscc from prices")

milk_price<-dbGetQuery(con,"select nn,pp from prices where revscc like '%Süt%'")
#create a table 
dbWriteTable(con, "milk_price", milk_price, row.names=FALSE, append=FALSE)
