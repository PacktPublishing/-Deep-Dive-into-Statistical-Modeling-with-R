#normal distribution

r1<-rnorm(100,10,5)

r2<-(rnorm(100,10,1))

r3<- rnorm(100)

#weibull

r4 <- rweibull(100,3,2)

#binomial

r5 <- rbinom(10,5,0.3)



