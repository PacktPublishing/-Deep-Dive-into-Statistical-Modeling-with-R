
data<-read.csv("dataset_tufe_vs_index.csv",header = T,sep = ",")

cor(data)
cor(data[,2:4])

require(Hmisc)

rcorr(cbind(data[,2],data[,3],data[,4]))

#regresyon modelini kuruyoruz.
model<-lm(data$tcmb_istanbul_2el~data$tufe)

#hata terimlerini buluyoruz
r<-resid(model)

#hata terimleri ile bağımlı değişken arasındaki ilişkiye bakıyoruz

plot(r,data$tcmb_istanbul_2el)

##fiyatlara log dönüşümü uyguluyoruz.

model2<-lm(log(data$tcmb_istanbul_2el)~data$tufe)

#hata terimlerini buluyoruz
r2<-resid(model2)

#hata terimleri ile bağımlı değişken arasındaki ilişkiye bakıyoruz
plot(r2,log(data$tcmb_istanbul_2el))

#Autocorrelation 
library(lmtest)
dwtest(model2)

#Heteroscedasticity
bptest(model2)


#Multicollinearity
library(car)
vif(model2)


