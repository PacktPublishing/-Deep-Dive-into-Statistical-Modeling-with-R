
data<-read.csv("dataset_tufe_vs_index.csv",header = T,sep = ",")

cpi <- data$tufe

ts_cpi <- ts(cpi, start=c(2010, 1), end=c(2015, 12), frequency=12) 

library(tseries)

adf.test(ts_cpi)

d_ts_cpi <- diff(ts_cpi,1)

adf.test(d_ts_cpi)

ar_model<- arima(d_ts_cpi,order = c(4, 0, 0))
ar_model

library(forecast)

forecast.Arima(ar_model,2)

